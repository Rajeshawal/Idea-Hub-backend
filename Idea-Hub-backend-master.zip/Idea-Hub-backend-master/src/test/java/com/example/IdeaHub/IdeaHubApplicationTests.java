package com.example.IdeaHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdeaHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
