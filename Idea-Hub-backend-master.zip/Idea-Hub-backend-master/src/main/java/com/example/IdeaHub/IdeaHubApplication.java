package com.example.IdeaHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdeaHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdeaHubApplication.class, args);
	}

}
